package Utils;

/**
 * Created by fandre on 08/10/14.
 */
public class Tuple<X, Y> {
    public X x;
    public Y y;

    public Tuple(X x, Y y) {
        this.x = x;
        this.y = y;
    }
}
